#!/bin/bash
# DEE System v1.8 ↔ v2.0 Full Deployment Script

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}   DEE SYSTEM v2.0 DEPLOYMENT          ${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker is not installed. Please install Docker first.${NC}"
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}❌ Docker Compose is not installed. Please install Docker Compose first.${NC}"
    exit 1
fi

# Check for .env file in backend
if [ ! -f backend/.env ]; then
    echo -e "${YELLOW}⚠️ backend/.env not found. Creating from template...${NC}"
    cat > backend/.env << EOF
DATABASE_URL=postgresql://dee_user:dee_password@postgres:5432/dee_system
REDIS_URL=redis://redis:6379
DEXSCREENER_API_KEY=your_dexscreener_api_key_here
EOF
    echo -e "${YELLOW}⚠️ Please edit backend/.env with your API keys before continuing.${NC}"
fi

# Stop existing containers
echo -e "${YELLOW}🛑 Stopping existing containers...${NC}"
docker-compose down -v

# Build Docker images
echo -e "${YELLOW}🔨 Building Docker images...${NC}"
docker-compose build --no-cache

# Start all services
echo -e "${YELLOW}🚀 Starting all services...${NC}"
docker-compose up -d

# Wait for services to be ready
echo -e "${YELLOW}⏳ Waiting for services to be ready...${NC}"
sleep 10

# Check service status
echo -e "${YELLOW}🔍 Checking service status...${NC}"
docker-compose ps

# Final status
echo ""
echo -e "${GREEN}✅ DEE System v2.0 deployed successfully!${NC}"
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}🌐 Frontend: http://localhost:3000${NC}"
echo -e "${GREEN}🔌 Backend API: http://localhost:8000${NC}"
echo -e "${GREEN}📊 API Documentation: http://localhost:8000/docs${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${YELLOW}📝 To view logs: docker-compose logs -f${NC}"
echo -e "${YELLOW}🛑 To stop: docker-compose down${NC}"
echo -e "${YELLOW}🔄 To restart: docker-compose restart${NC}"