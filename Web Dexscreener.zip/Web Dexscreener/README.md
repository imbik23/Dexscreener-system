# DEE System v2.0

Real-time crypto intelligence + decision engine dashboard berbasis pipeline v1.8 → v2.0 dengan full transparency.

## 🚀 Quick Start

```bash
# Clone repository
git clone https://github.com/yourusername/dee-system.git
cd dee-system

# Make deploy script executable
chmod +x deploy.sh

# Run deployment
./deploy.sh