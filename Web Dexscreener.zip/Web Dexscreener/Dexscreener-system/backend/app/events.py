from typing import List, Dict, Any
from datetime import datetime

class EventEmitter:
    def __init__(self, manager):
        self.manager = manager
        self.event_types = [
            "TOKEN_DISCOVERED",
            "TOKEN_VALIDATED",
            "TOKEN_REJECTED",
            "SCORE_UPDATED",
            "DECISION_MADE",
            "DEEP_VALIDATION_DONE",
            "EXECUTION_TRIGGERED"
        ]
        self.emitted_events = []
    
    async def emit(self, event_type: str, data: Dict[str, Any]) -> bool:
        """Emit event to all connected clients"""
        if event_type not in self.event_types:
            raise ValueError(f"Unknown event type: {event_type}")
        
        message = {
            "type": event_type,
            "data": data,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Broadcast to all connected clients
        await self.manager.broadcast(message)
        
        # Track emitted event
        self.emitted_events.append(message)
        
        # Keep only last 1000 events
        if len(self.emitted_events) > 1000:
            self.emitted_events = self.emitted_events[-1000:]
        
        return True
    
    async def emit_batch(self, events: List[Dict[str, Any]]) -> bool:
        """Emit multiple events"""
        for event in events:
            await self.emit(event["type"], event["data"])
        return True
    
    def get_events(self, event_type: str = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Get emitted events"""
        if event_type:
            events = [e for e in self.emitted_events if e["type"] == event_type]
        else:
            events = self.emitted_events
        
        return events[-limit:]
    
    def clear_events(self):
        """Clear all events"""
        self.emitted_events = []