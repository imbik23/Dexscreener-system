from typing import Dict, Any, Optional
from datetime import datetime

class LockedDataFlow:
    """LOCKED PIPELINE - DO NOT MODIFY"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.stage_order = [
            "raw_data",
            "safe_parse",
            "filter_layer",
            "scoring_engine_v1_8",
            "decision_engine",
            "v2_0_validation",
            "final_classification",
            "execution",
            "log_ui_stream"
        ]
        self.executed_stages = []
    
    async def run_pipeline(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute locked pipeline in order"""
        self.executed_stages = []
        pipeline_result = {}
        current_data = raw_data
        
        # Stage 1: RAW DATA
        self._validate_stage("raw_data")
        pipeline_result["stage_1_raw"] = self._validate_raw_data(raw_data)
        
        # Stage 2: SAFE PARSE
        self._validate_stage("safe_parse")
        current_data = self._safe_parse(pipeline_result["stage_1_raw"])
        pipeline_result["stage_2_parse"] = current_data
        
        # Stage 3: FILTER LAYER
        self._validate_stage("filter_layer")
        filtered = self._filter_layer(current_data)
        pipeline_result["stage_3_filter"] = filtered
        
        if not filtered:
            return self._early_reject("Filter layer rejected token", pipeline_result)
        
        # Stage 4: SCORING ENGINE v1.8
        self._validate_stage("scoring_engine_v1_8")
        score = self._scoring_engine(filtered)
        pipeline_result["stage_4_score"] = score
        
        # Stage 5: DECISION ENGINE
        self._validate_stage("decision_engine")
        decision = self._decision_engine(score)
        pipeline_result["stage_5_decision"] = decision
        
        # Stage 6: v2.0 VALIDATION (only for LONG)
        self._validate_stage("v2_0_validation")
        validation = None
        if decision["decision"] == "LONG":
            validation = self._v2_validation(filtered)
            pipeline_result["stage_6_validation"] = validation
        else:
            pipeline_result["stage_6_validation"] = None
        
        # Stage 7: FINAL CLASSIFICATION
        self._validate_stage("final_classification")
        classification = self._final_classification(decision, validation)
        pipeline_result["stage_7_classification"] = classification
        
        # Stage 8: EXECUTION (only for EXECUTE)
        self._validate_stage("execution")
        if classification["status"] == "EXECUTE":
            execution = self._execution(filtered)
            pipeline_result["stage_8_execution"] = execution
        else:
            pipeline_result["stage_8_execution"] = None
        
        # Stage 9: LOG + UI STREAM
        self._validate_stage("log_ui_stream")
        await self._log_ui_stream(pipeline_result)
        
        return pipeline_result
    
    def _validate_stage(self, stage_name: str) -> bool:
        """Validate stage order - cannot skip stages"""
        if stage_name not in self.stage_order:
            raise ValueError(f"Unknown stage: {stage_name}")
        
        expected_index = self.stage_order.index(stage_name)
        if len(self.executed_stages) != expected_index:
            raise RuntimeError(
                f"Cannot skip stages. Expected {self.stage_order[expected_index]}, "
                f"but previous stage was {self.executed_stages[-1] if self.executed_stages else 'NONE'}"
            )
        
        self.executed_stages.append(stage_name)
        return True
    
    def _validate_raw_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate raw data format"""
        required_fields = ["pairAddress", "baseToken", "priceUsd", "liquidity", "volume"]
        for field in required_fields:
            if field not in data:
                raise ValueError(f"Missing required field: {field}")
        return data
    
    def _safe_parse(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Sanitize and parse data"""
        return {
            "id": data.get("pairAddress", ""),
            "pair": data.get("baseToken", {}).get("symbol", "UNKNOWN"),
            "chain": data.get("chainId", "").upper(),
            "price": float(data.get("priceUsd", 0)),
            "liquidity": float(data.get("liquidity", {}).get("usd", 0)),
            "volume": float(data.get("volume", {}).get("h24", 0)),
            "holders": int(data.get("holders", 0)),
            "age": data.get("age", "0h"),
            "timestamp": datetime.utcnow().isoformat()
        }
    
    def _filter_layer(self, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Filter by minimum requirements"""
        min_liquidity = self.config.get("min_liquidity", 50000)
        min_volume = self.config.get("min_volume", 100000)
        min_holders = self.config.get("min_holders", 100)
        
        if data["liquidity"] < min_liquidity:
            return None
        if data["volume"] < min_volume:
            return None
        if data["holders"] < min_holders:
            return None
        
        return data
    
    def _scoring_engine(self, data: Dict[str, Any]) -> float:
        """Calculate EDS score"""
        liquidity_score = min(100, data["liquidity"] / 1000)
        volume_score = min(100, data["volume"] / 2000)
        holders_score = min(100, data["holders"] / 10)
        age_hours = float(data["age"].replace("h", "")) if "h" in data["age"] else 0
        age_score = min(100, 100 - (age_hours / 10))
        
        eds = (liquidity_score * 0.25) + (volume_score * 0.30) + (holders_score * 0.25) + (age_score * 0.20)
        return min(100, max(0, eds))
    
    def _decision_engine(self, score: float) -> Dict[str, Any]:
        """Generate decision based on score"""
        if score >= 80:
            return {"decision": "LONG", "bias": "CONTINUE", "phase": "GROWTH", "zone": "EARLY", "score": score}
        elif score >= 60:
            return {"decision": "OBSERVE", "bias": "FLAT", "phase": "BIRTH", "zone": "MID", "score": score}
        else:
            return {"decision": "NO TRADE", "bias": "REVERSE", "phase": "FAKE", "zone": "LATE", "score": score}
    
    def _v2_validation(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Deep validation for LONG signals"""
        health_score = min(100, data["liquidity"] / 500 + data["holders"] / 5)
        risk_score = min(100, 100 - health_score)
        
        if health_score >= 80:
            exit_risk = "GREEN"
            status = "VALID"
            grade = "A"
        elif health_score >= 70:
            exit_risk = "GREEN"
            status = "VALID"
            grade = "B"
        elif health_score >= 60:
            exit_risk = "YELLOW"
            status = "RISKY"
            grade = "C"
        else:
            exit_risk = "RED"
            status = "REJECTED"
            grade = "D"
        
        return {
            "status": status,
            "grade": grade,
            "confidence": health_score,
            "health_score": health_score,
            "risk_score": risk_score,
            "exit_risk": exit_risk
        }
    
    def _final_classification(self, decision: Dict[str, Any], validation: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Final classification"""
        if decision["decision"] != "LONG":
            return {"status": "HOLD", "reason": f"Decision is {decision['decision']}"}
        
        if not validation:
            return {"status": "HOLD", "reason": "No validation performed"}
        
        if validation["status"] == "VALID":
            return {"status": "EXECUTE", "grade": validation["grade"], "confidence": validation["confidence"]}
        elif validation["status"] == "RISKY":
            return {"status": "HOLD", "grade": validation["grade"], "reason": "Risky token"}
        else:
            return {"status": "DISCARD", "grade": validation["grade"], "reason": "Rejected by v2.0"}
    
    def _execution(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute trade"""
        position_size = self.config.get("position_size", 1000)
        sl_percent = self.config.get("stop_loss_percent", 15)
        tp1_percent = self.config.get("take_profit_1_percent", 15)
        tp2_percent = self.config.get("take_profit_2_percent", 30)
        tp3_percent = self.config.get("take_profit_3_percent", 50)
        
        return {
            "order_id": f"ORD-{int(datetime.utcnow().timestamp())}",
            "entry_price": data["price"],
            "position_size": position_size,
            "stop_loss": data["price"] * (1 - sl_percent / 100),
            "sl_percent": sl_percent,
            "take_profits": {
                "tp1": data["price"] * (1 + tp1_percent / 100),
                "tp1_percent": tp1_percent,
                "tp2": data["price"] * (1 + tp2_percent / 100),
                "tp2_percent": tp2_percent,
                "tp3": data["price"] * (1 + tp3_percent / 100),
                "tp3_percent": tp3_percent
            }
        }
    
    def _early_reject(self, reason: str, result: Dict[str, Any]) -> Dict[str, Any]:
        """Handle early rejection"""
        result["status"] = "REJECTED"
        result["reason"] = reason
        return result
    
    async def _log_ui_stream(self, result: Dict[str, Any]) -> None:
        """Stream to UI and database"""
        # This would be implemented with event_emitter
        pass