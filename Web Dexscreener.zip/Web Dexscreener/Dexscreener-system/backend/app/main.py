from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import asyncio
import json
from datetime import datetime
from typing import List, Dict, Any

from app.pipeline import LockedDataFlow
from app.events import EventEmitter
from app.websocket import ConnectionManager
from app.database import Database

app = FastAPI(
    title="DEE System Backend",
    version="2.0.0",
    description="Real-time crypto intelligence + decision engine"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize components
manager = ConnectionManager()
event_emitter = EventEmitter(manager)
database = Database()
pipeline = LockedDataFlow(config={
    "min_liquidity": 50000,
    "min_volume": 100000,
    "min_holders": 100,
    "position_size": 1000,
    "stop_loss_percent": 15,
    "take_profit_1_percent": 15,
    "take_profit_2_percent": 30,
    "take_profit_3_percent": 50
})

@app.on_event("startup")
async def startup_event():
    """Initialize database and start background tasks"""
    await database.initialize()
    print("✅ DEE System Backend started")

@app.on_event("shutdown")
async def shutdown_event():
    """Clean up resources"""
    await database.close()
    print("✅ DEE System Backend stopped")

@app.get("/")
async def root():
    return {
        "name": "DEE System v2.0",
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "database": await database.check_health(),
        "timestamp": datetime.utcnow().isoformat()
    }

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        await websocket.send_json({
            "type": "CONNECTION_ESTABLISHED",
            "data": {"status": "connected", "timestamp": datetime.utcnow().isoformat()}
        })
        
        while True:
            data = await websocket.receive_text()
            await websocket.send_json({
                "type": "PONG",
                "data": {"timestamp": datetime.utcnow().isoformat()}
            })
    except WebSocketDisconnect:
        manager.disconnect(websocket)

@app.post("/api/pipeline/run")
async def run_pipeline(data: dict):
    """Run pipeline on raw data"""
    try:
        result = await pipeline.run_pipeline(data)
        return JSONResponse(content=result, status_code=200)
    except Exception as e:
        return JSONResponse(content={"error": str(e)}, status_code=500)

@app.get("/api/tokens")
async def get_tokens(limit: int = 100):
    """Get all tokens from database"""
    tokens = await database.get_tokens(limit)
    return {"tokens": tokens}

@app.get("/api/decisions")
async def get_decisions(limit: int = 100):
    """Get all decisions from database"""
    decisions = await database.get_decisions(limit)
    return {"decisions": decisions}

@app.get("/api/stats")
async def get_stats():
    """Get system statistics"""
    stats = await database.get_stats()
    return stats