import asyncpg
from typing import List, Dict, Any, Optional
from datetime import datetime

class Database:
    def __init__(self):
        self.pool = None
        self.dsn = "postgresql://dee_user:dee_password@postgres:5432/dee_system"
    
    async def initialize(self):
        """Initialize database connection pool"""
        self.pool = await asyncpg.create_pool(
            self.dsn,
            min_size=1,
            max_size=10,
            command_timeout=60
        )
        print("✅ Database connected")
    
    async def close(self):
        """Close database connection pool"""
        if self.pool:
            await self.pool.close()
            print("✅ Database connection closed")
    
    async def check_health(self) -> bool:
        """Check database health"""
        try:
            async with self.pool.acquire() as conn:
                await conn.execute("SELECT 1")
            return True
        except Exception:
            return False
    
    async def get_tokens(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get tokens from database"""
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM tokens ORDER BY created_at DESC LIMIT $1",
                limit
            )
            return [dict(row) for row in rows]
    
    async def get_decisions(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get decisions from database"""
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM decisions ORDER BY created_at DESC LIMIT $1",
                limit
            )
            return [dict(row) for row in rows]
    
    async def get_stats(self) -> Dict[str, Any]:
        """Get system statistics"""
        async with self.pool.acquire() as conn:
            token_count = await conn.fetchval("SELECT COUNT(*) FROM tokens")
            decision_count = await conn.fetchval("SELECT COUNT(*) FROM decisions")
            execution_count = await conn.fetchval("SELECT COUNT(*) FROM executions")
            
            return {
                "tokens": token_count,
                "decisions": decision_count,
                "executions": execution_count,
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def insert_token(self, token_data: Dict[str, Any]) -> int:
        """Insert token into database"""
        async with self.pool.acquire() as conn:
            result = await conn.fetchval(
                """INSERT INTO tokens (address, pair, chain, price, liquidity, volume, holders) 
                   VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id""",
                token_data["id"],
                token_data["pair"],
                token_data["chain"],
                token_data["price"],
                token_data["liquidity"],
                token_data["volume"],
                token_data["holders"]
            )
            return result
    
    async def insert_decision(self, decision_data: Dict[str, Any]) -> int:
        """Insert decision into database"""
        async with self.pool.acquire() as conn:
            result = await conn.fetchval(
                """INSERT INTO decisions (token_id, decision, score, bias, phase, zone) 
                   VALUES ($1, $2, $3, $4, $5, $6) RETURNING id""",
                decision_data["token_id"],
                decision_data["decision"],
                decision_data["score"],
                decision_data.get("bias", ""),
                decision_data.get("phase", ""),
                decision_data.get("zone", "")
            )
            return result
    
    async def insert_execution(self, execution_data: Dict[str, Any]) -> int:
        """Insert execution into database"""
        async with self.pool.acquire() as conn:
            result = await conn.fetchval(
                """INSERT INTO executions (token_id, order_id, entry_price, position_size, status) 
                   VALUES ($1, $2, $3, $4, $5) RETURNING id""",
                execution_data["token_id"],
                execution_data["order_id"],
                execution_data["entry_price"],
                execution_data["position_size"],
                execution_data["status"]
            )
            return result