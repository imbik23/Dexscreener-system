from fastapi import WebSocket, WebSocketDisconnect
from typing import List, Dict, Any

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.connection_count: int = 0
    
    async def connect(self, websocket: WebSocket):
        """Accept WebSocket connection and add to active connections"""
        await websocket.accept()
        self.active_connections.append(websocket)
        self.connection_count += 1
        print(f"🔌 New connection. Total: {self.connection_count}")
    
    def disconnect(self, websocket: WebSocket):
        """Remove WebSocket from active connections"""
        self.active_connections.remove(websocket)
        self.connection_count -= 1
        print(f"🔌 Connection closed. Total: {self.connection_count}")
    
    async def broadcast(self, message: Dict[str, Any]):
        """Broadcast message to all connected clients"""
        disconnected = []
        
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except WebSocketDisconnect:
                disconnected.append(connection)
            except Exception as e:
                print(f"Error broadcasting: {e}")
                disconnected.append(connection)
        
        # Clean up disconnected connections
        for connection in disconnected:
            self.disconnect(connection)
    
    async def send_to_one(self, websocket: WebSocket, message: Dict[str, Any]):
        """Send message to specific client"""
        try:
            await websocket.send_json(message)
        except WebSocketDisconnect:
            self.disconnect(websocket)
        except Exception as e:
            print(f"Error sending to client: {e}")
    
    def get_connection_count(self) -> int:
        """Get number of active connections"""
        return self.connection_count
    
    def get_active_connections(self) -> List[WebSocket]:
        """Get list of active connections"""
        return self.active_connections