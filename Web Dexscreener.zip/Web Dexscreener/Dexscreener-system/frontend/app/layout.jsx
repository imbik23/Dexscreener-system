export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <title>DEE System v2.0</title>
        <meta name="description" content="Real-time crypto intelligence dashboard" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </head>
      <body>
        {children}
      </body>
    </html>
  );
}