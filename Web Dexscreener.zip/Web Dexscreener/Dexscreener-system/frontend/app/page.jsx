'use client';
import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';

export default function Dashboard() {
  const [isConnected, setIsConnected] = useState(false);
  const [events, setEvents] = useState([]);
  const [stats, setStats] = useState({
    scanned: 0,
    long: 0,
    observe: 0,
    noTrade: 0,
  });

  useEffect(() => {
    // Connect to WebSocket
    const socket = io('ws://localhost:8000/ws', {
      transports: ['websocket'],
      reconnection: true,
      reconnectionDelay: 1000,
    });

    socket.on('connect', () => {
      setIsConnected(true);
      console.log('WebSocket connected');
    });

    socket.on('disconnect', () => {
      setIsConnected(false);
      console.log('WebSocket disconnected');
    });

    socket.on('event', (data) => {
      setEvents((prev) => [data, ...prev].slice(0, 100));
      
      // Update stats based on events
      if (data.type === 'DECISION_MADE') {
        setStats(prev => ({
          ...prev,
          scanned: prev.scanned + 1,
          long: data.data.decision === 'LONG' ? prev.long + 1 : prev.long,
          observe: data.data.decision === 'OBSERVE' ? prev.observe + 1 : prev.observe,
          noTrade: data.data.decision === 'NO TRADE' ? prev.noTrade + 1 : prev.noTrade,
        }));
      }
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">DEE System v2.0</h1>
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
          <span className="text-sm text-gray-400">
            {isConnected ? 'Connected' : 'Disconnected'}
          </span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-[#1a1a1a] border border-[#333] rounded-lg p-4">
          <div className="text-gray-400 text-sm">Scanned</div>
          <div className="text-2xl font-bold">{stats.scanned}</div>
        </div>
        <div className="bg-[#1a1a1a] border border-[#333] rounded-lg p-4">
          <div className="text-gray-400 text-sm">LONG</div>
          <div className="text-2xl font-bold text-green-400">{stats.long}</div>
        </div>
        <div className="bg-[#1a1a1a] border border-[#333] rounded-lg p-4">
          <div className="text-gray-400 text-sm">OBSERVE</div>
          <div className="text-2xl font-bold text-yellow-400">{stats.observe}</div>
        </div>
        <div className="bg-[#1a1a1a] border border-[#333] rounded-lg p-4">
          <div className="text-gray-400 text-sm">NO TRADE</div>
          <div className="text-2xl font-bold text-red-400">{stats.noTrade}</div>
        </div>
      </div>

      {/* Events List */}
      <div className="bg-[#1a1a1a] border border-[#333] rounded-lg p-4">
        <h2 className="text-lg font-bold mb-4">Live Events</h2>
        <div className="space-y-2 max-h-[500px] overflow-y-auto">
          {events.map((event, idx) => (
            <div key={idx} className="bg-[#222] p-3 rounded border border-[#333]">
              <div className="flex justify-between">
                <span className="text-blue-400 font-bold">{event.type}</span>
                <span className="text-gray-400 text-xs">{event.timestamp}</span>
              </div>
              <pre className="text-xs text-gray-300 mt-1 overflow-auto">
                {JSON.stringify(event.data, null, 2)}
              </pre>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}